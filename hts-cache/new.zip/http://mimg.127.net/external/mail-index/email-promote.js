// 登录区广告内容
window.loginGGList = [
    {
        'name': '推荐邮箱官方app',
        'pic': 'https://mimg.127.net/index/lib/img/mailapp_logo_141212.png',
        'link': 'http://mail.163.com/client/dl.html?from=mail13',
        'tjName': 'b_login_box_logo-mailmaster_dl_click'
    }, {
        'name': '被删邮件能恢复了',
        'pic': 'https://mimg.127.net/index/lib/img/mailvip_logo_1.png',
        'link': 'https://v.mail.163.com/?utm_source=LoginBoxLogoShow_01',
        'tjName': 'b_login_box_logo-1_click'
    }, {
        'name': '不担心云附件过期',
        'pic': 'https://mimg.127.net/index/lib/img/mailvip_logo_3.png',
        'link': 'https://v.mail.163.com/?utm_source=LoginBoxLogoShow_00',
        'tjName': 'b_login_box_logo-2_click'
    }, {
        'name': '升级VIP邮箱，无限容量',
        'pic': 'https://mimg.127.net/index/lib/img/mailvip_logo_8_v1.png',
        'link': 'https://reg1.vip.163.com/newReg1/reg?from=LoginBoxLogoShow_03&utm_source=LoginBoxLogoShow_03',
        'tjName': 'b_login_box_logo-3_click'
    }, {
        'name': '邮件永久成铁证',
        'pic': 'https://mimg.127.net/index/lib/img/mailvip_logo_4.png',
        'link': 'https://v.mail.163.com/?utm_source=LoginBoxLogoShow_04',
        'tjName': 'b_login_box_logo-4_click'
    }, {
        'name': '升级VIP，安全性能提升30%',
        'pic': 'https://mimg.127.net/index/lib/img/mailvip_logo_6_v1.png',
        'link': 'https://reg1.vip.163.com/newReg1/reg?from=LoginBoxLogoShow_02&utm_source=LoginBoxLogoShow_02',
        'tjName': 'b_login_box_logo-5_click'
    }, {
        'name': '升级VIP，拦截99.99%的垃圾邮件',
        'pic': 'https://mimg.127.net/index/lib/img/mailvip_logo_7_v1.png',
        'link': 'https://reg1.vip.163.com/newReg1/reg?from=LoginBoxLogoShow_01&utm_source=LoginBoxLogoShow_01',
        'tjName': 'b_login_box_logo-6_click'
    }
];

// 公告配置
window.Notice = [
    {
        title: '公告：网易邮箱积分抽奖活动延期通知',
        url: 'https://mail.163.com/html/notice/2019/userclub-delay.html',
        start: new Date(2019,10,12,15,0,0).getTime(),
        end: new Date(2020,0,1,23,59,59).getTime(),
        domain: 'email',
        tjKey: 'b_UserClubDelayNoice',
        rate: 1
    }
];

// 视频广告配置
window.VideoPromotion = {
    show: false, // 开关，是否投放视频
    videoUrl: 'https://vodsl3orvte.vod.126.net/vodsl3orvte/YLaVYJkE_2664734758_hd.mp4', // 视频链接
    link: 'https://goods.kaola.com/product/5586142.html?tag=ea467f1dcce6ada85b1ae151610748b5&__da_5394f237_5b37360784792c00', // 推广链接
    pic: 'https://onegoods.nosdn.127.net/resupload/2019/8/30/a65cd9a74fd35bf6fe8cf3dd0eee4f72.svg', // 视频上方推广图
    backupPic: 'https://onegoods.nosdn.127.net/resupload/2019/9/2/fd0889e924cebfe659e9b303e8238df2.png', // 备用推广图，主要适用于低端浏览器
    ratio: 0.1, // 流量比例
    domain: '163,126,email', // 投放域
    autoPlay: true, // 是否自动播放
    loop: true, // 是否循环播放
    startTime: new Date(2019,8,3,0,0,0).getTime(),
    endTime: new Date(2019,8,6,23,59,59).getTime()
};
