<HEAD>
<TITLE>���׵�������</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=gb2312">
<style type="text/css">
<!--
body,input{font-size:12px;margin:0;	padding:0;font-family:verdana,Arial, Helvetica, sans-serif;	color:#000}
body{text-align:center; margin:0 auto}
.title{background-color:#35AEE3;font-weight:bold;color:#fff;padding:6px 10px 8px 7px;}
.errMainArea{width:546px; margin:80px auto 0 auto;text-align:left; border:1px solid #aaa}	
	.errTxtArea{ padding:30px 34px 0 110px;}
		.errTxtArea .txt_title{	font-size:150%;	font-weight:bolder;	font-family:"Microsoft JhengHei","΢ܛ�����w","Microsoft YaHei","΢���ź�";}	
	.errBtmArea{ padding:10px 8px 25px 8px ;background-color:#fff;text-align:center; }
.btnFn1 {cursor:pointer!important;cursor:hand;  height:30px; width:101px; padding:3px 5px 0 0; font-weight:bold; }

-->
</style>
</HEAD>
<div class="errMainArea" >
	<div   class="title" >ϵͳ��ʾ</div>
	<div class="errTxtArea"> 
	<p class="txt_title" >�Բ������ҵ��ļ����������Ҳ��� !</p></div><div class="errBtmArea">
    <input type="button" class="btnFn1" value="������ҳ" onclick="location.href='http://email.163.com/'" />
  </div>

</div>
  

</body>
</html>

